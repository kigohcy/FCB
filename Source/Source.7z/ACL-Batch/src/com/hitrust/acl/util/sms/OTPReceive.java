package com.hitrust.acl.util.sms;

public class OTPReceive {
	public String RowId;
	public String ErrorCode;
}
