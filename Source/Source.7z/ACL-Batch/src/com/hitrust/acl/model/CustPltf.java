/**
 * @(#) CustPltf.java
 * 
 * Copyright (c) 2017 HiTRUST Incorporated. All rights reserved.
 * 
 * Modify History:
 *	v1.00, 2017/09/16, Evan
 * 	 1)First release
 *  
 */
package com.hitrust.acl.model;

import java.io.Serializable;

import com.hitrust.acl.model.base.AbstractCustPltf;

public class CustPltf extends AbstractCustPltf implements Serializable {
	private static final long serialVersionUID = 2823922993256305756L;
	
}
