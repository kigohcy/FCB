/**
 * 
 */
package com.hitrust.bank.telegram.res;

/**
 * @author bing
 *
 */
public interface ResponseInfo {
	String getResponseId();
}
