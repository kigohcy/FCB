/**
 * 
 */
package com.hitrust.bank.telegram.req;

/**
 * @author bing
 *
 */
public interface RequestInfo {
	String getRequestId();
	void setRequestId(String requestId);

}
