/**
 * @(#) TsbApauditlogDAO.java
 *
 * Directions:
 *
 * Copyright (c) 2016 HiTRUST Incorporated.
 * All rights reserved.
 *
 * Modify History:
 *   v1.00, 2016/04/18, Eason Hsu
 *    1) JIRA-Number, First release
 *
 */

package com.hitrust.bank.dao;

import com.hitrust.framework.dao.BaseDAO;

public interface TsbApauditlogDAO extends BaseDAO {

}
