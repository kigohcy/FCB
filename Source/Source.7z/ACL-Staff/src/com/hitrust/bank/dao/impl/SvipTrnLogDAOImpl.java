/**
 * @(#) SvipTrnLogDAOImpl.java
 *
 * Directions: 敏感客戶查詢LOG檔 DAO
 *
 * Copyright (c) 2016 HiTRUST Incorporated.
 * All rights reserved.
 *
 * Modify History:
 *   v1.00, 2016/06/23, Eason Hsu
 *    1) First release
 *
 */

package com.hitrust.bank.dao.impl;

import com.hitrust.bank.dao.SvipTrnLogDAO;
import com.hitrust.framework.dao.impl.BaseDAOImpl;

public class SvipTrnLogDAOImpl extends BaseDAOImpl implements SvipTrnLogDAO {

}
