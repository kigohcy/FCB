package com.hitrust.bank.servlet;

import javax.servlet.http.HttpServlet;

import org.apache.log4j.Logger;

public class KaptchaImageServlet extends HttpServlet {
	static Logger LOG = Logger.getLogger(KaptchaImageServlet.class);
	
	public void getKaptchaImage(){
		
	}
}
