/**
 * @(#) TxncsSvipSrvImpl.java
 *
 * Directions: 敏感戶查詢處理
 *
 * Copyright (c) 2016 HiTRUST Incorporated.
 * All rights reserved.
 *
 * Modify History:
 *   v1.00, 2016/06/24 Eason Hsu
 *    1) First release
 *
 */

package com.hitrust.bank.service.impl;

import com.hitrust.bank.service.TxncsSvipSrv;

public class TxncsSvipSrvImpl implements TxncsSvipSrv {
	
}
