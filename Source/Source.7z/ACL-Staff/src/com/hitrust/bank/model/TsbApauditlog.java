/**
 * @(#) TsbApauditlog.java
 *
 * Directions: 應用系統日誌
 *
 * Copyright (c) 2016 HiTRUST Incorporated.
 * All rights reserved.
 *
 * Modify History:
 *   v1.00, 2016/04/18, Eason Hsu
 *    1) JIRA-Number, First release
 *
 */

package com.hitrust.bank.model;

import com.hitrust.bank.model.base.AbstractTsbApauditlog;

public class TsbApauditlog extends AbstractTsbApauditlog {

	private static final long serialVersionUID = 5375829778708085077L;

}
