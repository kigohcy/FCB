/**
 * @(#) StaffLogin.java
 *
 * Copyright (c) 2016 HiTRUST Incorporated.
 * All rights reserved.
 * 
 * Modify History:
 *	v1.00, 2016/1/28, Eason Hsu
 * 	 1) JIRA-Number, First release
 * 
 */

package com.hitrust.bank.model;

import com.hitrust.bank.model.base.AbstractStaffLogin;

public class StaffLogin extends AbstractStaffLogin {

	private static final long serialVersionUID = -704149393417222055L;
	
	// =============== Not Table Attribute ===============

}
