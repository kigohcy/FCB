/**
 * @(#) TxncsSvip.java
 *
 * Directions: 敏感客戶名單檔
 *
 * Copyright (c) 2016 HiTRUST Incorporated.
 * All rights reserved.
 *
 * Modify History:
 *   v1.00, 2016/06/23, Eason Hsu
 *    1) First release
 *
 */

package com.hitrust.bank.model;

import com.hitrust.bank.model.base.AbstractTxncsSvip;

public class TxncsSvip extends AbstractTxncsSvip {

	private static final long serialVersionUID = 7834009159341788349L;
	
	// =============== Not Table Attribute ===============

}
