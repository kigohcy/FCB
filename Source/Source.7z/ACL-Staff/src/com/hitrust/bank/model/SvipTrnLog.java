/**
 * @(#) SvipTrnLog.java
 *
 * Directions: 敏感客戶查詢LOG檔
 *
 * Copyright (c) 2016 HiTRUST Incorporated.
 * All rights reserved.
 *
 * Modify History:
 *   v1.00, 2016/06/23, Eason Hsu
 *    1) First release
 *
 */

package com.hitrust.bank.model;

import com.hitrust.bank.model.base.AbstractSvipTrnLog;

public class SvipTrnLog extends AbstractSvipTrnLog {

	private static final long serialVersionUID = 672825632345838087L;
	
	// =============== Not Table Attribute ===============
	
}
