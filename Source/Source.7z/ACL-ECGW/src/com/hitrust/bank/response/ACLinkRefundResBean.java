/**
 * @(#) ACLinkRefundResBean.java
 *
 * Copyright (c) 2016 HiTRUST Incorporated. All rights reserved.
 *
 * Description : ACLinkRefundRes bean
 * 
 * Modify History:
 *  v1.00, 2016/03/29, Yann
 *   1) First release
 *  
 */
package com.hitrust.bank.response;

import com.hitrust.acl.response.AbstractResponseBean;

public class ACLinkRefundResBean extends AbstractResponseBean {
	
	public ACLinkRefundResBean() {
		super();
	}
}
